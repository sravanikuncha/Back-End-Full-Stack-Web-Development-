import OrderModel from "./order.schema.js";

export const createNewOrderRepo = async (data,user) => {
  // Write your code here for placing a new order
  console.log(user)
  data.user=user._id;
  data.paidAt=Date.now();
  data.deliveredAt=Date.now();
  data.createdAt=Date.now();
  return await new OrderModel(data).save();
};
