import ProductModel from "./product.schema.js";

export const addNewProductRepo = async (product) => {
  return await new ProductModel(product).save();
};

export const getAllProductsRepo = async (page,updates) => {

  let skip=0;
  let limit=0;
  if(page){
     limit=3;
     skip=(page-1)*limit;
  }

  const keyword=updates.keyword;
  const category=updates.category;
  const pricelte=updates.pricelte;
  const pricegte=updates.pricegte;
  const ratinglte=updates.ratinglte;
  const ratinggte=updates.ratinggte;
 console.log(updates);
  const filter={};
  if(keyword){
    const regex = new RegExp(keyword, 'i');
    filter.name=regex;
  }
  if(category){
    filter.category=category
  }
  if(pricelte){
    filter.price={
      $lte:pricelte
    }
  }
  if(pricegte){
    if(filter.price){
      filter.price.$gte=pricegte
    }else{
      filter.price={$gte:pricegte}
    }
  }

  if(ratinglte){
    filter.rating={$lte:ratinglte};
  }
  if(ratinggte){
    if(filter.rating){
     filter.rating.$gte=ratinggte;
    }else{
      filter.rating={$gte:ratinggte};
    }
  }
  console.log(filter);
  return await ProductModel.find(filter).skip(skip).limit(limit);
  
};

export const updateProductRepo = async (_id, updatedData) => {
  return await ProductModel.findByIdAndUpdate(_id, updatedData, {
    new: true,
    runValidators: true,
    useFindAndModify: true,
  });
};

export const deleProductRepo = async (_id) => {
  return await ProductModel.findByIdAndDelete(_id);
};

export const getProductDetailsRepo = async (_id) => {
  return await ProductModel.findById(_id);
};

export const getTotalCountsOfProduct = async () => {
  return await ProductModel.countDocuments();
};

export const findProductRepo = async (productId) => {
  return await ProductModel.findById(productId);
};
