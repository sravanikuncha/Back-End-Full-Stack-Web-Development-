// Import the necessary modules here
import nodemailer from 'nodemailer';
import fs from 'fs';
import path from 'path';
import handlebars from 'handlebars';

export const sendWelcomeEmail = async (user) => {

  //logoPath
  const logoPath=path.join(path.resolve(),'backend','public','assets','capstonelogo.png');
  const logoData = fs.readFileSync(logoPath).toString('base64');
  // Write your code here
  const email=user?.email;
  const name=user.name;
  const port=process.env.PORT;

  const htmlpath=path.join(path.resolve(),'backend','public','index.html');
  const textContet=fs.readFileSync(htmlpath).toString();


  let transport=nodemailer.createTransport({
    service:process.env.SMPT_SERVICE,
    auth:{
      user:process.env.STORFLEET_SMPT_MAIL,
      pass:process.env.STORFLEET_SMPT_MAIL_PASSWORD,
    }
  });
  const personalizedHtml = textContet
  .replace('{{name}}', name)
  .replace('{{port}}', port)
  .replace('{{localhost}}',process.env.LOCAL_HOST);

  try{
    const mailOptions ={
      from:process.env.STORFLEET_SMPT_MAIL,
      subject:"Welcome Mail",
      to:email,
      html:personalizedHtml,
      attachments: [
        {
            filename: 'capstonelogo.png',
            path: logoPath,
            cid: 'logo' // same cid value as in the html img src
        },
    ],
    }

    
    console.log(mailOptions);
    const output=await transport.sendMail(mailOptions);
    console.log("Success: Email sent to "+email);
    transport.close();
}
catch(err){
  console.log("failed");
  console.log(err);
  transport.close();
}
};
